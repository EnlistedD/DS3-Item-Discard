Compile In: Microsoft Visual Studio 2017
Compile As: Release, x64